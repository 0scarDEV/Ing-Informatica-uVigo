package ejercicio1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PlatoTest {

    // COMPLETAR: escribe aquí los tests indicados en el enunciado
}
