package ejercicio3;

import ejercicio2.TipoReserva;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

// Tests para la clase Reserva.
//
// Se deben escribir tests que comprueben:
//
// 1. Que el constructor crea la reserva correctamente y los getters devuelven los valores esperados.
// 2. Que el constructor lanza IllegalArgumentException con un localizador inválido (null o vacío).
// 3. Que depositoNetoFinal() devuelve el depósito menos la señal requerida del tipo de reserva.
class ReservaTest {

    // Escribe aquí tus tests

}
