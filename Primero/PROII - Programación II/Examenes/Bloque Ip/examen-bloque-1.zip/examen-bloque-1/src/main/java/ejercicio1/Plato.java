package ejercicio1;

public class Plato {

    // COMPLETAR: declara los campos, constructores y métodos indicados en el enunciado
}
