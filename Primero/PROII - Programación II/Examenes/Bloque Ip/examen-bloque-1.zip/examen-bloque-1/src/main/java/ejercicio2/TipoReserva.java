package ejercicio2;

public enum TipoReserva {

    // COMPLETAR: añade la señal requerida como parámetro a cada constante
    //       y completa el constructor y el campo privado del enum
    NORMAL,
    GRUPO,
    EXCLUSIVA;

    // COMPLETAR: declara un campo privado double para la señal requerida

    // COMPLETAR: declara el constructor del enum que reciba la señal requerida

    // NORMAL -> 0.0, GRUPO -> 10.0, EXCLUSIVA -> 50.0
    public double getSenalRequerida() {
        throw new UnsupportedOperationException("COMPLETAR");
    }
}
