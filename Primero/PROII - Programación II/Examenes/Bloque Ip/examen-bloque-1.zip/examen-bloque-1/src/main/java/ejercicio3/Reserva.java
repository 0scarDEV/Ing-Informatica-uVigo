package ejercicio3;

import ejercicio2.TipoReserva;

public class Reserva {

    // COMPLETAR: declara los campos necesarios

    // localizador y nombreCliente no pueden ser null ni vacíos; lanza IllegalArgumentException si lo son
    // deposito debe ser >= 0.0; lanza IllegalArgumentException si no lo es
    // tipo no puede ser null; lanza IllegalArgumentException si lo es
    public Reserva(String localizador, String nombreCliente, double deposito, TipoReserva tipo) {
        throw new UnsupportedOperationException("COMPLETAR");
    }

    public String getLocalizador() {
        throw new UnsupportedOperationException("COMPLETAR");
    }

    public String getNombreCliente() {
        throw new UnsupportedOperationException("COMPLETAR");
    }

    // nombreCliente no puede ser null ni vacío; lanza IllegalArgumentException si lo es
    public void setNombreCliente(String nombreCliente) {
        throw new UnsupportedOperationException("COMPLETAR");
    }

    public double getDeposito() {
        throw new UnsupportedOperationException("COMPLETAR");
    }

    public TipoReserva getTipo() {
        throw new UnsupportedOperationException("COMPLETAR");
    }

    public static int getTotalReservas() {
        throw new UnsupportedOperationException("COMPLETAR");
    }

    // Calcula el depósito después de descontar la señal requerida del tipo de reserva
    public double depositoNetoFinal() {
        throw new UnsupportedOperationException("COMPLETAR");
    }

    // Ejemplo: "Reserva[RES001] María Pérez (GRUPO) - 100.0 €"
    @Override
    public String toString() {
        throw new UnsupportedOperationException("COMPLETAR");
    }
}
